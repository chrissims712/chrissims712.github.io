In this folder there are three items that are to be used by the program:
1) The .gpx file titled "AutumnRidge.gpx"
	